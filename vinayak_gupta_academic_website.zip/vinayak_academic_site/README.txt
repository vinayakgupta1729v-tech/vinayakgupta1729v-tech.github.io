VINAYAK GUPTA — PERSONAL ACADEMIC WEBSITE

1. Open index.html in any modern browser to preview the site.
2. Upload index.html to GitHub Pages, Netlify, or any static website hosting service to publish it.
3. Edit index.html to change text, publication records, colors, or links.
4. The page uses Google Fonts when internet is available and falls back to system fonts offline.

Includes: mobile responsive layout, about and education, research themes, 9 CV-listed journal publications with DOI links, publication year filters, LinkedIn, ResearchGate, email.

Before publishing: review the wording and affiliations for personal accuracy. No photograph or unverifiable Scholar/ORCID link was inserted.
